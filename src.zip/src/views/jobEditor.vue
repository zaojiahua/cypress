<template>
  <div id="wrap" ref="jobEditor">
    <Drawer title="用例详细信息" :closable="false" v-model="showDrawer" width="50">
      <job-msg-component ref="jobDetail" :prop-confirm-btn="false" :prop-enter-btn="false"></job-msg-component>
    </Drawer>
    <div class="jobName">
      jobName: {{jobName}}<job-in-job :jobModalShow="jobModalShow"></job-in-job>
      <Button size="large" style="float: right" to="/jobList">取消</Button> <!-- @click="$store.commit('noKeepAlive', 'jobEditor')"-->
      <Button type="primary" size="large" @click="saveJob" style="margin-right: 10px">确定</Button>
      <Button type="primary" size="large" @click="viewResFile" style="margin-right: 10px">查看依赖文件</Button>
      <Button type="info" size="large" @click="showDrawer=true" style="margin-right: 10px">详情</Button>
      <!-- <Button :type="$store.state.keepAliveComponents.length === 2 ? 'success' : 'warning'"
        size="large"
        @click="$store.commit('keepAlive', 'jobEditor')"
        style="margin-right: 10px">
        {{ this.$store.state.keepAliveComponents.length === 2 ? "已存" : "暂存" }}
      </Button> -->
      <i-switch size="large" v-show="switchButtonShow" v-model="switchButton">
        <span slot="open">另存</span>
        <span slot="close">更新</span>
      </i-switch>
    </div>
    <!-- <job-editor-header :jobName="jobName" @saveJob="saveJob" @showDrawer="showDrawerHandler"></job-editor-header> -->
    <job-in-job :jobModalShow="jobModalShow" :currentJobBlockText="currentJobBlockText" @jobModalClose="jobModalClose"></job-in-job>
    <job-res-file ref="jobResFile" :jobName="jobName" :resFileModalShow="resFileModalShow" @resFileModalClose="resFileModalClose"></job-res-file>
    <unit-editor :unitName="unitName" :unitContent="unitContent" :unitEditorModalShow="unitEditorModalShow" @closeUnitEditor="closeUnitEditor" @saveRawUnit="saveRawUnit" @saveUnit="saveUnit"></unit-editor>
    <div id="chart-wrap">
      <div id="chart-palette"></div>
      <div id="chart-diagram"></div>
    </div>

    <Modal v-model="blockModalShow" :closable="false" fullscreen>
      <div slot="header">
        <Input v-model="blockName" size="large" placeholder="large size" />
      </div>
      <div slot="footer">
        <Button type="text" size="large" @click="blockModalShow=false">取消</Button>
        <Button type="primary" size="large" @click="saveNormalBlock">确定</Button>
      </div>
      <div id="inner-wrap">
        <div id="chart-left">
          <div id="dropdown-div" align="center">
            <Dropdown trigger="click" @on-click="getSelectedUnit">
              <Button id="dropdown-btn" type="primary">{{unitType}}</Button>
              <DropdownMenu slot="list" style="width: 150px">
                <DropdownItem v-for="(currentUnit, key) in unitAllList" :name="key" :key="key">{{key}}</DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
          <div id="inner-palette"></div>
        </div>
        <div id="tooltip">
          <Card v-show="unitMsgToogle" style="background-color: rgba(255, 255, 255, .95);">
            <p slot="title"><Icon type="ios-book-outline" />Unit Message</p>
            <pre>{{ unitContent }}</pre>
         </Card>
         <Card v-show="!unitMsgToogle">
            <p slot="title"><Icon type="ios-document-outline" />Unit Files</p>
            <Row style="width: 320px; display: flex; justify-content: space-between;">
              <Col span="12">
                <Table :columns="unitInputFileColumns" :data="unitInputFileData" width="150" border></Table>
              </Col>
              <Col span="12" style="margin-left: 20px;">
                <Table :columns="unitOutputFileColumns" :data="unitOutputFileData" width="150" border></Table>
              </Col>
            </Row>
         </Card>
        </div>
        <div id="inner-diagram"></div>
      </div>
    </Modal>
    <!-- <job-editor-job-flow-editor :blockModalShow="blockModalShow" @blockModalClose="blockModalClose"></job-editor-job-flow-editor> -->

    <switch-block-detail-component
      :switch-block-info="switchBlockInfo"
      v-model="switchBlockModalShow"
      @save="switchBlockSave"
      @clear="switchBlockInfo = {}">
    </switch-block-detail-component>
  </div>
</template>
<script>
import go from 'gojs'
import {
  MAKE,
  showLinkLabel,
  finishDrop,
  linkTemplateStyle,
  startNodeTemplate,
  endNodeTemplate,
  unitNodeTemplate,
  baseNodeTemplateForPort,
  baseGroupTemplate,
  basicModel
} from './jobEditorCommon'
import jobMsgComponent from '../components/jobMsgComponent'
import jobInJob from '../components/jobInJob'
import jobResFile from '../components/jobResFile'
import unitEditor from '../components/unitEditor'
import { getTemporarySpace } from '../api/coral/jobLibSvc'
import { getJobUnitsBodyDict } from '../api/reef/unit'
import { getBlockFlowDict4Font, jobFlowAndMsgSave, jobFlowAndMsgUpdate } from '../api/reef/jobFlow'
import { jobResFilesSave } from '../api/reef/jobResFileSave'
import SwitchBlockDetailComponent from '../components/SwitchBlockDetailComponent'
import { commonValidation } from '../core/validation/common'
import {
  startValidation
} from '../core/validation/operationValidation/job'
import { unitListValidation } from '../core/validation/operationValidation/block'
import { jobFlowValidation } from '../core/validation/finalValidation/job'
import { blockFlowValidation } from '../core/validation/finalValidation/block'
import axios from '../api'
import { baseURL } from '../config'

export default {
  name: 'jobEditor',
  components: { SwitchBlockDetailComponent, jobMsgComponent, jobInJob, jobResFile, unitEditor },
  data () {
    return {
      jobName: '',
      blockModalShow: false,
      jobOperationComponentShow: false,
      switchBlockModalShow: false,
      currentSwitchBlockKey: null,
      unitName: null,
      unitContent: '',
      blockName: '',
      stageJobLabel: null,
      unitNodeByKey: null,
      getCurrentNormalBlockByKey: null,
      unitType: '请选择组件类型',
      switchBlockInfo: {},
      unitAllList: {},
      basicModuleShow: {},
      switchButtonShow: false,
      switchButton: false,
      showDrawer: false,
      isCertain: false, // 是否是通过点击确定按钮离开jobEditor页面
      screenWidth: 1400,
      ingroneList: ['login'],
      jobModalShow: false,
      currentJobBlockKey: null,
      currentJobBlockText: 'Job block',
      resFileModalShow: false,
      unitMsgToogle: true,
      unitInputFileColumns: [
        {
          title: 'InputFile',
          key: 'file_name',
          align: 'center'
        }
      ],
      unitInputFileData: [],
      unitOutputFileColumns: [
        {
          title: 'OutputFile',
          key: 'file_name',
          align: 'center'
        }
      ],
      unitOutputFileData: [],
      unitEditorModalShow: false
    }
  },
  mounted () {
    const _this = this
    _this.$Notice.config({
      top: 150,
      duration: 10
    })

    myDiagramInit()
    function myDiagramInit () {
      _this.myDiagram = MAKE(go.Diagram, 'chart-diagram', {
        initialContentAlignment: go.Spot.Center,
        allowDrop: true,
        // 设置网格
        grid: MAKE(go.Panel, 'Grid',
          MAKE(go.Shape, 'LineH', {
            stroke: 'lightgray',
            strokeWidth: 0.5
          }),
          MAKE(go.Shape, 'LineH', {
            stroke: 'gray',
            strokeWidth: 0.5,
            interval: 10
          }),
          MAKE(go.Shape, 'LineV', {
            stroke: 'lightgray',
            strokeWidth: 0.5
          }),
          MAKE(go.Shape, 'LineV', {
            stroke: 'gray',
            strokeWidth: 0.5,
            interval: 10
          })
        ),
        // 拖动时是否捕捉网格点
        'draggingTool.isGridSnapEnabled': true,
        // 初次链接时，以链接（link）头部距离目标节点的某个Port的距离小于linkingTool.portGravity时，链接会自动吸附到目标节点的Port上
        'linkingTool.portGravity': 40,
        // 修改链接时，以链接（link）头部距离目标节点的某个Port的距离小于linkingTool.portGravity时，链接会自动吸附到目标节点的Port上
        'relinkingTool.portGravity': 40,
        'toolManager.mouseWheelBehavior': go.ToolManager.WheelZoom,
        'LinkDrawn': showLinkLabel,
        'LinkRelinked': showLinkLabel,
        mouseDrop: function (e) {
          finishDrop(e, null)
        },
        'undoManager.isEnabled': true
      })

      _this.myDiagram.linkTemplate = linkTemplateStyle()

      _this.myDiagram.linkTemplate.doubleClick = function (e, node) {
        if (e.diagram instanceof go.Palette) return
        let block = _this.myDiagram.findNodeForKey(node.data.from).data

        if (block.category === 'normalBlock') {
          // vm.showDrawerOperation('linkOperation')
          // currentLinkObj = node
        }
      }

      const startTemplate = startNodeTemplate('#00AD5F')
      startTemplate.linkValidation = startValidation

      const endTemplate = endNodeTemplate('tomato')

      endTemplate.doubleClick = (e, node) => {
        if (node.data.text === 'End') {
          _this.myDiagram.model.setDataProperty(node.data, 'text', 'Fail')
          _this.myDiagram.model.setDataProperty(node.data, 'color', '#A9A9A9')
        } else {
          _this.myDiagram.model.setDataProperty(node.data, 'text', 'End')
          _this.myDiagram.model.setDataProperty(node.data, 'color', '#DC3C00')
        }

        debugger
      }

      const switchBlockTemplate = baseNodeTemplateForPort(MAKE(go.Brush, go.Brush.Linear, { 0.0: '#74ebd5', 1.0: '#9face6' }), 'Diamond')
      switchBlockTemplate.doubleClick = function (e, node) {
        _this.$Notice.destroy()
        if (e.diagram instanceof go.Palette) return

        _this.switchBlockInfo = {
          switchBlockName: node.data.text,
          fileName: node.data.fileName,
          explain: node.data.explain
        }
        _this.currentSwitchBlockKey = node.data.key

        _this.switchBlockModalShow = true
      }

      const normalBlockTemplate = baseNodeTemplateForPort(MAKE(go.Brush, go.Brush.Linear, { 0.0: '#30cfd0', 1.0: '#330867' }), 'RoundedRectangle')

      normalBlockTemplate.doubleClick = function (e, node) {
        _this.$Notice.destroy()
        if (e.diagram instanceof go.Palette) return
        _this.unitType = '请选择组件类型'
        _this.blockName = node.data.text
        _this.getCurrentNormalBlockByKey = node.data.key
        _this.blockModalShow = true
        if (!_this.blockDiagram) blockDiagramInit()
        if (!_this.blockPalette) blockPaletteInit()
        if (!node.data.unitLists) { // unitList存在则展示
          _this.blockDiagram.model = go.Model.fromJson({
            'class': 'go.GraphLinksModel',
            'linkFromPortIdProperty': 'fromPort',
            'linkToPortIdProperty': 'toPort',
            'nodeDataArray': [],
            'linkDataArray': []
          })
        } else {
          // 通过 lodbash deepCopy 一份数据并传递给 _this.blockDiagram.model
          _this.blockDiagram.model = go.Model.fromJson(_this._.cloneDeep(node.data.unitLists))
        }
      }

      const jobBlockTemplate = baseNodeTemplateForPort(MAKE(go.Brush, go.Brush.Linear, { 0.0: '#30cfd0', 1.0: '#2306F7' }), 'RoundedRectangle')
      jobBlockTemplate.doubleClick = function (e, node) {
        if (e.diagram instanceof go.Palette) return
        _this.currentJobBlockText = node.data.text
        _this.currentJobBlockKey = node.data.key
        _this.jobModalShow = true
      }

      _this.myDiagram.nodeTemplateMap.add('normalBlock', normalBlockTemplate)
      _this.myDiagram.nodeTemplateMap.add('switchBlock', switchBlockTemplate)
      _this.myDiagram.nodeTemplateMap.add('Start', startTemplate)
      _this.myDiagram.nodeTemplateMap.add('End', endTemplate)
      _this.myDiagram.nodeTemplateMap.add('Job', jobBlockTemplate)

      _this.myDiagram.toolManager.linkingTool.linkValidation = commonValidation
      _this.myDiagram.toolManager.relinkingTool.linkValidation = commonValidation
    }

    function blockDiagramInit () {
      _this.blockDiagram = MAKE(go.Diagram, 'inner-diagram', {
        initialContentAlignment: go.Spot.Center,
        allowDrop: true,
        'toolManager.mouseWheelBehavior': go.ToolManager.WheelZoom,
        mouseDrop: function (e) {
          finishDrop(e, null)
        },
        'undoManager.isEnabled': true
      })

      // -------------从Palette拖拽节点的触发事件，判断Unit是否被UnitList包含------------
      _this.blockDiagram.addDiagramListener('externalobjectsdropped', function (e) {
        e.subject.each(function (n) {
          // 得到从Palette拖过来的节点 判断节点如果没有group则删除节点
          if (n.data.category === 'Unit') {
            if (!n.data.group) { // 判断Unit是否被UnitList包含
              _this.blockDiagram.commandHandler.deleteSelection()// 删除该选中节点
              _this.$Message.error('Unit只能被包裹在UnitList中') // 错误提示
            }
          }
        })
      })

      _this.blockDiagram.linkTemplate = linkTemplateStyle()

      const unitTemplate = unitNodeTemplate('#c924c9', 'RoundedRectangle')
      // unitTemplate.doubleClick = function (e, node) {
      //   if (e.diagram instanceof go.Palette) return
      //   _this.$Notice.destroy()
      //   _this.$refs.emptyOperation.deviceRefresh() // 双击unit时刷新device列表
      //   _this.$refs.emptyOperation.emptyData()
      //   _this.unitModalShow = true
      //   _this.unitNodeByKey = node.data.key
      //   _this.unitName = node.data.text
      //   _this.unitContent = JSON.stringify(node.data.unitMsg, null, 2)
      // }

      let tooltip = document.querySelector('#tooltip')
      let example = {
        category: 'Unit'
      }
      let inputPattern = /<blkInpPath>.*png/
      let outputPattern = /<blkOutPath>.*png/ // (?<=\<span[^>]*\>).*?(?=\<\/span>)
      let inputFile, outputFile

      unitTemplate.doubleClick = function (e, node) {
        if (e.diagram instanceof go.Palette) return
        _this.unitMsgToogle = !_this.unitMsgToogle
        _this.unitEditorModalShow = true
        _this.unitNodeByKey = node.data.key
        _this.unitName = node.data.text

        // let units = e.diagram.findNodesByExample(example) // 模糊查找，找到所有的 Unit
        // units.iterator.each(unit => {
        //   let unitMsgCmdDict = JSON.stringify(unit.data.unitMsg.execCmdDict, null, 2)
        //   if (outputFile && unitMsgCmdDict && (unitMsgCmdDict.indexOf('<blkInpPath>' + outputFile[0].split('>')[1]) !== -1)) {
        //     unit.isSelected = true
        //   }
        //   if (inputFile && unitMsgCmdDict && (unitMsgCmdDict.indexOf('<blkOutPath>' + inputFile[0].split('>')[1]) !== -1)) {
        //     unit.isSelected = true
        //   }
        // })
      }

      unitTemplate.mouseEnter = function (e, node) {
        _this.unitContent = JSON.stringify(node.data.unitMsg, null, 2)
        outputFile = JSON.stringify(node.data.unitMsg, null, 2).match(outputPattern)
        if (outputFile) {
          _this.unitOutputFileData = []
          _this.unitOutputFileData.push({
            file_name: outputFile[0].split('>')[1]
          })
        }

        inputFile = JSON.stringify(node.data.unitMsg, null, 2).match(inputPattern)
        if (inputFile) {
          _this.unitInputFileData = []
          _this.unitInputFileData.push({
            file_name: inputFile[0].split('>')[1]
          })
        }
        tooltip.style.display = 'block'
      }

      unitTemplate.mouseOver = function (e, node) {
        if (e.diagram instanceof go.Palette) return
        tooltip.style.top = `${e.event.y}px`
        tooltip.style.left = `${e.event.x}px`
      }

      unitTemplate.mouseLeave = function (e, node) {
        if (e.diagram instanceof go.Palette) return
        tooltip.style.display = 'none'

        let units = e.diagram.findNodesByExample(example) // 模糊查找 node
        units.iterator.each(unit => {
          unit.isSelected = false
        })

        _this.unitOutputFileData = []
        _this.unitInputFileData = []
      }

      const unitListGroupTemplate = baseGroupTemplate()
      unitListGroupTemplate.memberValidation = function groupValidation (group, node) {
        return node.data.category === 'Unit'// 当节点的category值为Unit时
      }

      unitListGroupTemplate.linkValidation = unitListValidation

      _this.blockDiagram.nodeTemplateMap.add('Unit', unitTemplate)
      _this.blockDiagram.nodeTemplateMap.add('Start', startNodeTemplate('#00AD5F'))
      _this.blockDiagram.nodeTemplateMap.add('End', endNodeTemplate('tomato'))
      _this.blockDiagram.groupTemplateMap.add('UnitList', unitListGroupTemplate)

      _this.blockDiagram.toolManager.linkingTool.linkValidation = commonValidation
      _this.blockDiagram.toolManager.relinkingTool.linkValidation = commonValidation
    }

    function blockPaletteInit () {
      _this.blockPalette =
        MAKE(go.Palette, 'inner-palette',
          {
            nodeTemplateMap: _this.blockDiagram.nodeTemplateMap,
            groupTemplateMap: _this.blockDiagram.groupTemplateMap,
            layout: MAKE(go.GridLayout, { wrappingColumn: 1, alignment: go.GridLayout.Position })
          })
      let basicModule = {
        'nodeDataArray': [
          { category: 'Start', text: 'Entry' },
          { category: 'Unit', text: 'Unit' },
          { category: 'UnitList', text: 'UnitList', isGroup: true },
          { category: 'End', text: 'Exit' }
        ]
      }

      _this.basicModuleShow = {
        key: 'basicModule',
        value: basicModule
      }
      _this.blockPalette.model = new go.GraphLinksModel(basicModule.nodeDataArray, basicModule.linkDataArray)
    }
    getJobUnitsBodyDict().then(res => {
      res.data.unit.forEach((unit, index) => {
        if (!(unit.type in this.unitAllList)) {
          this.$set(this.unitAllList, unit.type, {})
        }
        this.$set(this.unitAllList[unit.type], unit.unit_name, unit.unit_content)
      })
      this.$set(this.unitAllList, 'Basic Module', this.basicModuleShow)
    })
    this.init()
  },
  beforeCreate () {
    const _this = this
    window.onload = () => {
      _this.screenWidth = document.body.clientWidth
    }
    window.onresize = () => {
      return (() => {
        window.screenWidth = document.body.clientWidth
        _this.screenWidth = window.screenWidth
      })()
    }
  },
  // beforeDestroy () {
  //   console.log(this.$refs.jobEditor)
  // },
  // 提醒用户暂存已编辑的内容
  // beforeRouteLeave (to, from, next) {
  //   let _this = this
  //   let toFullPath = to.fullPath
  //   if (this.$store.state.keepAliveComponents.length !== 2 && this.myDiagram.model.nodeDataArray.length !== 0 && !this.isCertain && this.ingroneList.indexOf(to.name) === -1) {
  //     this.$Modal.confirm({
  //       title: 'WARNING',
  //       content: '此操作会丢失已编辑的内容，确定要继续吗？',
  //       closable: false,
  //       okText: '保存并退出',
  //       cancelText: '退出',
  //       onOk () {
  //         _this.$store.commit('keepAlive', 'jobEditor')
  //         next(false)
  //         setTimeout(function () {
  //           _this.$router.push({ path: toFullPath })
  //         }, 100)
  //       },
  //       onCancel () {
  //         next()
  //       }
  //     })
  //   } else {
  //     next()
  //   }
  // },
  methods: {
    init () {
      this.myPalette = MAKE(
        go.Palette, 'chart-palette', {
          scrollsPageOnFocus: false,
          nodeTemplateMap: this.myDiagram.nodeTemplateMap,
          layout: MAKE(go.GridLayout, { wrappingColumn: 1, alignment: go.GridLayout.Location })
        }
      )

      this.myPalette.model = new go.GraphLinksModel([
        { category: 'Start', text: 'Start' },
        { category: 'switchBlock', text: 'Switch block' },
        { category: 'normalBlock', text: 'Normal block' },
        { category: 'End', text: 'End' },
        { category: 'Job', text: 'Job block' }
      ])

      if (this.$route.query.jobFlow) {
        getBlockFlowDict4Font(this.$route.query.jobFlow).then(res => {
          if (JSON.stringify(res.data) === '{}') {
            this.$Message.warning('这个job不存在')
            return this.$router.push({ path: '/' })
          }
          this.stageJobLabel = this.$route.query.jobLabel
          this.jobName = this.$route.query.jobName
          this.$refs.jobDetail.getMsg(this.$route.query.jobId)
          this.myDiagram.model = go.Model.fromJson(res.data)
          this.switchButtonShow = true
        })
      } else {
        this.$refs.jobDetail.getMsg()
        getTemporarySpace().then(res => {
          // this.stageJobLabel = res.data.stageJobLabel
          // this.$refs.jobDetail.getMsg()
          this.myDiagram.model = basicModel()
        })
      }
    },
    switchBlockSave (msg) {
      let node = this.myDiagram.model.findNodeDataForKey(this.currentSwitchBlockKey)
      this.myDiagram.model.setDataProperty(node, 'text', msg.switchBlockName)
      this.myDiagram.model.setDataProperty(node, 'fileName', msg.fileName)
      this.myDiagram.model.setDataProperty(node, 'explain', msg.explain)
    },
    saveNormalBlock () { // normalBlock点击确定进行校验
      let currentNormalBlockData = this.myDiagram.findNodeForKey(this.getCurrentNormalBlockByKey).data

      let blockDiagramData = JSON.parse(this.blockDiagram.model.toJson())

      const blockDiagramHint = blockFlowValidation(this)

      this.$Notice.destroy()

      if (blockDiagramHint.size !== 0) {
        this.blockModalShow = true
        let errorNum = 1
        let errorMessage = ''
        blockDiagramHint.forEach(element => {
          errorMessage += errorNum + '.' + element + '<br/>'
          errorNum++
        })
        // message提示

        this.$Notice.error({
          title: '当前block出现以下错误',
          desc: errorMessage
        })
      } else {
        this.blockModalShow = false
        this.myDiagram.model.setDataProperty(currentNormalBlockData, 'unitLists', blockDiagramData)
        this.myDiagram.model.setDataProperty(currentNormalBlockData, 'text', this.blockName)
      }
    },
    _jobFlowRules () {
      const myDiagramEventValidationHint = jobFlowValidation(this)

      this.$Notice.destroy()

      // 错误提示
      if (myDiagramEventValidationHint.size !== 0) {
        let errorNum = 1
        let errorMessage = ''
        myDiagramEventValidationHint.forEach(element => {
          errorMessage += errorNum + '.' + element + '<br/>'
          errorNum++
        })

        // message提示
        this.$Notice.error({
          title: '当前用例出现以下错误',
          desc: errorMessage // 提示内容
        })
        return false
      } else return true
    },
    _jobMsgRules () {
      let flag = true
      this.$refs.jobDetail.$refs.jobInfoForm.validate((valid) => {
        if (!valid) {
          this.showDrawer = true
          flag = false
        }
      })
      return flag
    },
    // 生成 jobLabel
    _createJobLabel (src) {
      let jobLabel = this.md5(this.myDiagram.model.toJson())
      jobLabel = 'job-' + jobLabel.substr(0, 8) + '-' + jobLabel.substr(8, 4) + '-' + jobLabel.substr(12, 4) + '-' + jobLabel.substr(16, 4) + '-' + jobLabel.substr(20)
      return jobLabel
    },
    _createNewTag (tagType) { // 生成新的测试用途、自定义标签条目
      let requests = []
      let targetName = tagType === 'test_area' ? 'job_test_area' : 'custom_tag'
      let target = this.$refs.jobDetail.jobInfo[tagType]
      for (let i = target.length - 1; i > 0; i--) {
        if (typeof target[i] !== 'number') {
          requests.push(
            axios.request({
              url: `${baseURL}/api/v1/cedar/${targetName}/`,
              method: 'post',
              data: tagType === 'test_area' ? { description: target[i] } : { custom_tag_name: target[i] }
            }).then(res => {
              target[i] = res.data.id
            })
          )
        }
      }
      return Promise.all(requests)
    },
    _getData () {
      let filesData = this.$refs.jobResFile.filesData
      let data = new FormData()
      data.append('job', this.$route.query.jobId)
      for (let i = 0; i < filesData.length; i++) {
        let file = null
        if (filesData[i].type === 'jpg' || filesData[i].type === 'png') {
          file = this._dataURLtoFile(filesData[i].file, filesData[i].name)
        } else {
          file = new File([filesData[i].file], filesData[i].name, { type: filesData[i].type })
        }
        data.append('file', file)
      }
      return data
    },
    _dataURLtoFile (dataurl, filename) {
      var arr = dataurl.split(',')
      var mime = arr[0].match(/:(.*?);/)[1]
      var dec = atob(arr[1]) // window atob() 方法用于解码使用 base-64 编码的字符串，base-64 编码使用的是 btoa，该方法使用 "A-Z", "a-z", "0-9", "+", "/" 和 "=" 字符来编码字符串。
      var n = dec.length
      var u8arr = new Uint8Array(n) // 8位无符号整数数组 0~255
      while (n--) {
        u8arr[n] = dec.charCodeAt(n) // charCodeAt() 方法可返回指定位置的字符的 Unicode 编码
      }
      return new File([u8arr], filename, { type: mime })
    },
    saveJob () {
      // 使用 & 保证都运行
      if (this._jobFlowRules() & this._jobMsgRules()) {
        let info = this.$refs.jobDetail.jobInfo
        let jobFlow = this.myDiagram.model.toJson()
        Promise.all([this._createNewTag('test_area')]).then(() => { // this._createNewTag('custom_tag') API暂时不能用
          // console.log(this.$refs.jobDetail.jobInfo.test_area)
          let id = this.$route.query.jobId
          info.ui_json_file = JSON.parse(jobFlow)
          if (!id) { // 新建job
            info.job_label = this._createJobLabel(jobFlow)
            jobFlowAndMsgSave(info).then(res => {
            // 保存成功后跳转回jobList页面
              if (res.status === 200) {
                this.isCertain = true
                this.$router.push({ path: '/jobList' })
                this.$Message.info('操作完成')
              } else {
                console.log(res)
              }
            }).catch(res => {
              debugger
            })
          } else { // 更新job
            let data = this._getData() // 准备要上传的依赖文件

            jobFlowAndMsgUpdate(id, info).then(res => { // 保存job
              if (res.status === 200) {
                this.$Message.info('Job 保存成功')

                jobResFilesSave(data).then(res => { // 上传依赖文件
                  if (res.status === 201) {
                    this.isCertain = true
                    this.$Message.info('Job 依赖文件保存成功')
                    console.log('更新成功')
                    this.$router.push({ path: '/jobList' })
                  } else {
                    console.log(res)
                  }
                })
              } else {
                console.log(res)
              }
            })
          }
        })
      }
    },
    saveUnit (unitName) {
      this.unitName = unitName
      let currentUnitNode = this.blockDiagram.findNodeForKey(this.unitNodeByKey).data
      this.blockDiagram.model.setDataProperty(currentUnitNode, 'unitMsg', JSON.parse(this.unitContent))
      this.blockDiagram.model.setDataProperty(currentUnitNode, 'text', this.unitName)
      this.unitEditorModalShow = false
    },
    getSelectedUnit (name) {
      let unitCategoryData = {}
      unitCategoryData.nodeDataArray = []
      this.unitType = name
      if (name !== 'Basic Module') {
        Object.entries(this.unitAllList[name]).forEach((unit) => {
          unitCategoryData.nodeDataArray.push({
            category: 'Unit',
            text: unit[0],
            unitContent: unit[1]
          })
        })
        this.blockPalette.model = new go.GraphLinksModel(unitCategoryData.nodeDataArray)
      } else {
        this.blockPalette.model = new go.GraphLinksModel(this.basicModuleShow.value.nodeDataArray, this.basicModuleShow.value.linkDataArray)
      }
    },
    jobModalClose (job) {
      this.jobModalShow = false
      if (job.id) {
        console.log('您选中的job为：', job.id)
        let currentJobBlockData = this.myDiagram.findNodeForKey(this.currentJobBlockKey).data
        this.myDiagram.model.setDataProperty(currentJobBlockData, 'text', job.job_name)
        this.myDiagram.model.setDataProperty(currentJobBlockData, 'jobId', job.id)
        console.log(currentJobBlockData)
      }
    },
    viewResFile () {
      this.resFileModalShow = true
    },
    resFileModalClose () {
      this.resFileModalShow = false
    },
    closeUnitEditor () {
      this.unitEditorModalShow = false
    },
    saveRawUnit (unitContent) {
      this.unitContent = unitContent
    }
  },
  created () {
    this.$bus.on('saveRawUnit', rawUnitMsg => {
      this.saveRawUnit(rawUnitMsg)
    })
  },
  beforeDestroy () {
    this.$bus.off('saveRawUnit')
  }
}
</script>
<style lang="less" scoped>
  .jobName {
    font-size: 18px;
    padding: 5px 20px
  }

  .jobName Button{
    float: right;
    margin-bottom: 5px;
  }

  #chart-wrap {
    width: 100%;
    display: flex;
    height: 83vh;
    justify-content: space-between;
    margin-bottom: 22px;

    #chart-palette {
      width: 15%;
      margin-right: 30px;
      background-color: white;
      border: solid 1px rgb(244, 244, 244);
    }

    #chart-diagram {
      flex-grow: 1;
      background-color: white;
      border: solid 1px rgb(244, 244, 244);
    }
  }

    #inner-wrap {
      width: 100%;
      display: flex;
      height: 78vh;
      justify-content: space-between;
      margin-bottom: 22px;

      #chart-left{
        width: 15%;
        margin-right: 30px;
        background-color: white;
        border: solid 1px rgb(244, 244, 244);

        #dropdown-div{
          width: 100%;
          height: 10%;

          #dropdown-btn{
            width: 100%;
            margin-top: 10px;
            letter-spacing: 2px;
            font-size: 14px;
          }
        }
        #inner-palette {
          width: 100%;
          height: 90%;
          background-color: white;
        }
      }
      #tooltip {
        display: none;
        position: absolute;
        z-index: 1000000000;
        border-radius: 10px;
        box-shadow: 6px 8px 12px gray;
      }

      #inner-diagram{
        position: relative;
        flex-grow: 1;
        background-color: white;
        border: solid 1px rgb(244, 244, 244);
      }
    }

    .unitView{
      width: 100%;
      display: flex;
      height: 74vh;
      justify-content: space-between;
      margin-bottom: 22px;

      .unitContent {
        width: 20%;
        margin-right: 16px;
        background-color: white;
        border: solid 1px rgb(244, 244, 244);
      }

      .unitOperation{
        width: 80%;
        flex-grow: 1;
        background-color: white;
        border: solid 1px rgb(244, 244, 244);
      }
    }
</style>
