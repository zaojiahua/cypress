<template>
  <div class="home">
    <layout></layout>
  </div>
</template>

<script>
// @ is an alias to /src
import layout from '../components/layout.vue'

export default {
  name: 'home',
  components: {
    layout
  }
}
</script>
