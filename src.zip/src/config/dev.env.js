export default {
  'REEF_HOST': '10.80.3.138',
  'CORAL_HOST': '10.80.3.100'
}
