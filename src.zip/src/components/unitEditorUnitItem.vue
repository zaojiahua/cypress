<template>
  <div class="item" :class="{active: checked}" @click="handleClick">
    <p class="item-data" v-html="currentItemData"></p>
    <Checkbox v-model="isComplete" disabled style="float: right;"></Checkbox>
  </div>
</template>

<script>
import { findBrothersComponents } from '../lib/tools.js'

export default {
  name: 'unit-item',
  props: {
    itemData: {
      type: String,
      default: ''
    },
    itemType: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      isComplete: false,
      currentItemData: this.itemType + ':' + this.itemData,
      checked: false
    }
  },
  methods: {
    handleClick () {
      this.checked = true
      let unitItemBrothers = findBrothersComponents(this, 'unit-item')
      unitItemBrothers.forEach(bro => {
        bro.checked = false
      })
    }
  },
  mounted () {
    if (this.itemData.indexOf('a') !== -1) this.isComplete = true
    this.currentItemData = this.currentItemData.split('<').join('&lt;')
    this.currentItemData = this.currentItemData.split('&lt;unitfile>').join('<span style="color: red">&lt;unitfile></span>')
    this.currentItemData = this.currentItemData.split('&lt;jobres_file>').join('<span style="color: red">&lt;jobres_file></span>')
    this.currentItemData = this.currentItemData.split('&lt;/jobres_file>').join('<span style="color: red">&lt;/jobres_file></span>')
    this.currentItemData = this.currentItemData.split('&lt;input_file>').join('<span style="color: red">&lt;input_file></span>')
    this.currentItemData = this.currentItemData.split('&lt;/input_file>').join('<span style="color: red">&lt;/input_file></span>')
  }
}
</script>

<style lang="less" scoped>
.item {
    display: flex;
    justify-content: space-between;
    border: 1px solid #eeeeee;
    border-radius: 6px;
    padding: 10px 6px;
    margin: 10px 0;
    margin-right: 10px;
    &:hover {
      box-shadow: inset 0px 0px 20px #a5d0e4;
      border-color: #a7dbf3;
    }
    &:checked {
        box-shadow: inset 0px 0px 20px #093549;
        border-color: #072c3d;
    }

    .item-data {
      width: 92%;
      word-wrap:break-word;
      word-break:break-all;
      overflow: hidden;
    }
}
.active {
    box-shadow: inset 0px 0px 20px #c1dfec;
    border-color: #a2c6d6;
}
</style>
