<template>
  <Modal v-model="unitEditorModalShow" :closable="false" width="90">
    <div slot="header">Unit Editor</div>
    <div slot="footer">
      <Button @click="closeUnitEditor">确定</Button>
    </div>
    <div class="unit-editor">
      <div class="container">
        <div class="unit-items-container">
          <Card style="height: 320px;">
            <p slot="title">Unit Items &nbsp; {{  }}</p>
            <div class="unit-items">
              <unit-editor-unit-item
                v-for="(item, key, index) in unitItemDatas"
                :key="index"
                :itemData="item"
                :itemType="key"
                @click.native="editItem(index)"
              ></unit-editor-unit-item>
            </div>
          </Card>
        </div>
        <div class="raw-unit-container">
          <div class="raw-unit-mask" v-show="isEditing"></div>
          <Card style="height: 500px; z-index: 20;">
            <p slot="title">Raw Unit &nbsp;({{ unitMsgObj ? unitMsgObj.execModName : '' }} Unit)</p>

            <div v-show="!isEditing" class="raw-unit">
              <div class="unit-msg">
                <pre>{{ currentUnitMsgStr }}</pre>
              </div>
              <div class="btns">
                <Button @click="editCurrentMsgStr">
                  <Icon type="ios-clipboard-outline" />编辑
                </Button>
              </div>
            </div>
            <div v-show="isEditing" class="raw-unit">
              <div class="unit-msg" @keydown.tab="handleKeydown">
                <Input
                  type="textarea"
                  :autosize="{minRows: 2,maxRows: 17}"
                  v-model="currentUnitMsgStr"
                />
              </div>
              <div class="btns" style="justify-content: flex-end;">
                <Button @click="cancelEditCurrentMsgStr" style="margin-right: 10px;">取消</Button>
                <Button type="primary" @click="saveCurrentMsgStr">保存</Button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div class="container">
        <Card>
          <p slot="title">Item Edit &nbsp; {{ currentItem !== -1 ? '(第' + (currentItem + 1) + '个)' : '' }}</p>
          <div v-show="!isEditingItem" style="height: 755px;"></div>
          <div class="items-edit" v-show="isEditingItem">
            <div>
              <div class="data-type">
                <div>
                  <p>请选择数据类型：</p>
                  <RadioGroup v-model="data.type">
                    <Radio label="ux_input">&lt;ux_input></Radio>
                    <Radio label="input_file">&lt;input_file></Radio>
                    <Radio label="jobres_file">&lt;jobres_file></Radio>
                  </RadioGroup>
                </div>
                <div>
                  <Button @click="reset">重置</Button>
                </div>
              </div>
              <div v-if="data.type === 'ux_input'">
                <p>请输入数据：</p>
                <Input type="text" v-model="data.content" />
              </div>
              <div v-else-if="data.type === 'input_file'">
                <p>请输入文件名：</p>
                <Input type="text" v-model="data.content" />
              </div>
              <div v-else-if="data.type === 'jobres_file'">
                <div style="margin-bottom: 10px; margin-top: 20px;">
                  <p v-show="!file" style="padding: 6px 0;">请上传文件：</p>
                  <Input v-model="fileParams.name" v-if="file"><span slot="prepend">文件名称</span></Input>
                </div>
                <Upload multiple type="drag" :before-upload="handleUpload" action="//jsonplaceholder.typicode.com/posts/">
                  <div style="padding: 20px 0" v-if="!file">
                    <Icon type="ios-cloud-upload" size="80" style="color: #3399ff"></Icon>

                    <p style="margin-top: 20px;">点击或将文件拖拽到这里上传</p>
                    <p>文件格式：txt/jpg/png/mp4/mov...</p>
                  </div>
                  <div style="padding: 20px 0" v-if="file">
                    <Icon type="ios-document-outline"  size="80" style="color: #3399ff" v-show="isText"></Icon>
                    <Icon type="ios-images" size="80" style="color: #3399ff" v-show="isImage"/>
                    <Icon type="ios-videocam-outline" size="80" style="color: #3399ff" v-show="isVideo"/>
                    <p style="margin-top: 20px;">文件名称：{{ fileParams.name }}</p>
                    <p>文件类型：{{ fileParams.type }}</p>
                  </div>
                </Upload>
              </div>
            </div>
            <div class="save-btn">
              <Button type="primary" @click="saveItemChange">保存</Button>
            </div>
          </div>
        </Card>
      </div>
      <div class="container">
        <Card>
          <p slot="title">File &nbsp; {{ file ? '(' + fileParams.name + ')' : '' }}</p>
          <div class="file-gallery">
            <p class="file-none" v-show="!file">还没有可以展示/编辑的文件</p>
            <div v-show="file" class="file-container">
              <div v-if="isText" class="text">
                <Input v-model="fileToShow" type="textarea" :rows="16" />
              </div>
              <div v-if="isImage" class="image">
                <img :src="fileToShow">
              </div>
              <div v-if="isVideo" class="video">
                <video :src="fileToShow" controls></video>
              </div>
            </div>

          </div>
        </Card>
      </div>
    </div>
  </Modal>
</template>

<script>
import unitEditorUnitItem from './unitEditorUnitItem'
import {
  isJsonString,
  insertAfterCursor,
  findComponentsDownward,
  fileToDataURL,
  dataURLtoFile
} from '../lib/tools.js'

export default {
  components: { unitEditorUnitItem },
  props: {
    unitEditorModalShow: {
      type: Boolean,
      default: false
    },
    unitMsgStr: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      currentUnitMsgStr: this.unitMsgStr,
      unitMsgObj: null,
      unitItemDatas: {},
      unitItems: [],
      isEditing: false,
      isEditingItem: false,
      currentItem: -1,
      data: {
        type: '',
        content: ''
      },
      file: null,
      fileParams: {
        name: '',
        type: ''
      },
      fileToShow: '',
      isImage: false,
      isText: false,
      isVideo: false
    }
  },
  watch: {
    unitMsgStr (val) {
      this.currentUnitMsgStr = val
      this.unitMsgObj = JSON.parse(val)
      let execCmdDict = this.unitMsgObj.execCmdDict
      this.$set(this.unitItemDatas, 'referImgFile', execCmdDict.referImgFile)
      this.$set(this.unitItemDatas, 'configFile', execCmdDict.configFile)
      this.$set(this.unitItemDatas, 'inputImgFile', execCmdDict.inputImgFile)
      this.$set(this.unitItemDatas, 'imgCmpThreshold', execCmdDict.imgCmpThreshold)
    },
    file (val) {
      if (val) {
        console.log(val)
        this.$set(this.fileParams, 'name', val.name)
        this.$set(this.fileParams, 'type', val.type)
        if (val.type.split('/')[0] === 'image') {
          this.isImage = true
          this.isText = false
          this.isVideo = false
          fileToDataURL(val).then(res => {
            this.fileToShow = res
          })
        } else if (val.type.split('/')[0] === 'application' || val.type.split('/')[0] === 'text') {
          this.isText = true
          this.isImage = false
          this.isVideo = false
          let reader = new FileReader()
          reader.readAsText(val)
          reader.onload = () => {
            this.fileToShow = reader.result
          }
        } else if (val.type.split('/')[0] === 'video') {
          this.isVideo = true
          this.isText = false
          this.isImage = false
          fileToDataURL(val).then(res => {
            this.fileToShow = res
          })
        }
      }
    }
  },
  methods: {
    closeUnitEditor () {
      this.$emit('closeUnitEditor')
    },
    editItem (index) {
      let _this = this
      if (_this.isEditingItem) {
        if (_this.currentItem !== index && _this.data.type !== '') {
          _this.$Modal.confirm({
            title: '温馨提示:',
            content: '此操作会丢失当前编辑的内容，确定要继续吗？',
            onOk () {
              _this.reset()
              _this.currentItem = index
              _this.isText = false
              _this.isImage = false
              _this.isVideo = false
            },
            onCancel () {
              let unitItems = document.querySelector('.unit-items')
              unitItems.childNodes[_this.currentItem].click()
            }
          })
        } else {
          _this.currentItem = index
        }
      } else {
        _this.currentItem = index
        _this.isEditingItem = true
      }
    },
    editCurrentMsgStr () {
      this.isEditing = true
    },
    handleKeydown (event) {
      let insertStr = '  '
      event.preventDefault()
      insertAfterCursor(event.target, insertStr)
    },
    cancelEditCurrentMsgStr () {
      this.isEditing = false
      this.currentUnitMsgStr = this.unitMsgStr
    },
    saveCurrentMsgStr () {
      if (!isJsonString(this.currentUnitMsgStr)) {
        this.$Message.error({
          background: true,
          content: '不是 JSON 格式'
        })
      } else {
        this.$Message.success({
          background: true,
          content: '保存成功'
        })
        this.isEditing = false
      }
    },
    reset () {
      this.data.type = ''
      this.data.content = ''
      this.file = null
    },
    handleUpload (file) {
      this.file = file
      return false
    },
    saveItemChange () {
      this.file = dataURLtoFile(this.fileToShow, this.fileParams.name)
      console.log(this.file)
      this.isEditingItem = false
      this.currentItem = -1
      this.unitItems.forEach(item => {
        item.checked = false
      })
      this.reset()
      this.$Message.success({
        background: true,
        content: '保存成功'
      })
    }
  },
  beforeUpdate () {
    this.unitItems = [...findComponentsDownward(this, 'unit-item')]
  }
}
</script>

<style lang="less" scoped>
::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
::-webkit-scrollbar-thumb {
  // background-color: #a1a3a9;
  border-radius: 3px;
  // background-color: rgb(136, 135, 219);
  background-image: -webkit-linear-gradient(
      45deg,
      // rgba(4, 81, 182, 0.8) 6%,
      // rgba(6, 105, 44, 0.8) 18%,
      // rgba(112, 216, 42, 0.8) 25%,
      // rgba(89, 0, 206, 0.8) 50%,
      // rgba(125, 69, 228, 0.8) 60%,
      // rgba(192, 45, 113, 0.8) 75%,
      // rgba(112, 216, 42, 0.8)
      rgba(35, 35, 36, 0.8) 6%,
      rgba(120, 134, 125, 0.8) 18%,
      rgba(170, 190, 157, 0.8) 25%,
      rgba(137, 125, 153, 0.8) 50%,
      rgba(86, 76, 104, 0.8) 60%,
      rgba(138, 94, 115, 0.8) 75%,
      rgba(107, 140, 167, 0.8)
  );
}
.unit-editor {
  display: flex;
  justify-content: space-between;

  .container {
    width: 32.8%;

    .unit-items-container {
      // height: 38%;

      .unit-items {
        height: 240px;
        overflow: auto;
      }
    }

    .raw-unit-container {
      height: 58%;
      margin-top: 20px;

      .raw-unit-mask {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 10;
        background-color: rgba(0, 0, 0, 0.8);
        width: 3000px;
        height: 3000px;
      }

      .raw-unit {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 420px;

        .unit-msg {
          max-height: 88%;
          overflow: auto;
        }

        .btns {
          height: 10%;
          display: flex;
          align-items: center;
        }
      }
    }

    .items-edit {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 755px;

      .data-type {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
      }

      .save-btn {
        display: flex;
        justify-content: center;
      }
    }

    .file-gallery {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 755px;

      .file-none {
        padding: 40px;
        border: 1px dashed #dddddd;
        border-radius: 6px;
        background-color: rgba(0, 0, 0, 0.4);
        color: white;
      }

      .file-container {
        flex: 1;
        height: 100%;

        .text {

        }

        .image {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100%;

          img {
            max-width: 100%;
          }
        }

        .video {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100%;

          video {
            max-height: 755px;
          }
        }
      }
    }
  }
}
</style>
