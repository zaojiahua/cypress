<template>
  <div>
    <img src="../assets/image/404.jpg" class="img-responsive">
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
  .img-responsive {
    display: inline-block;
    height: auto;
    max-width: 100%;
  }
</style>
