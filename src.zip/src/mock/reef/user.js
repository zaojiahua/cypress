export const login = (options) => {
  return {
    id: 3,
    last_name: 'das',
    token: 'a556f377c6e8e2034da8e0de28b27765daeff14a',
    username: 'gj'
  }
}
