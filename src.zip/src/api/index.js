import HttpRequest from '../lib/axios'
const axios = new HttpRequest()
export default axios
